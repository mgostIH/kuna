int4 compact_dispatch(ModeStore *store,uint4 mode) // return-dupe
{
  mode -= 5;
  if (4 <= mode)
    return 0x10e;
  while( true ) {
    switch(*(char *)((int4)mode + 0x401055L)) {
      case 0:
        return 300;
      case 1:
        return 0x10e;
      case 2:
        return 0xf0;
      
    }
    if (store->mode == 8) break;
    mode = store->mode - 5;
    if (4 <= mode)
      return 0x10e;
  }
  return 0x10e;
}
