#!/usr/bin/env python3
"""Original x86-64 compact-switch fixture. Python standard library only."""
import argparse
import ctypes
import json
import mmap
from pathlib import Path
import platform
import struct
import subprocess

BASE, ENTRY, OFFSET = 0x400000, 0x401000, 0x1000
MAP = bytes((0, 3, 1, 2))


def build():
    code, labels, branches = bytearray(), {}, []

    def label(name):
        labels[name] = len(code)

    def branch(op, name):
        code.extend(bytes.fromhex(op))
        branches.append((len(code), name))
        code.extend(bytes(4))

    def ret(value):
        code.extend(b'\xb8' + struct.pack('<I', value) + b'\xc3')

    code.extend(bytes.fromhex('83 c2 fb 83 fa 03'))  # EDX=mode-5; CMP index,3
    branch('0f 87', 'default')                    # JA default
    code.extend(bytes.fromhex('4c 8d 05'))         # LEA R8,image base
    base_fix = len(code)
    code.extend(bytes(4))
    label('lookup')
    code.extend(bytes.fromhex('48 63 c2 41 0f b6 84 00'))  # RAX=index; EAX=map[index]
    map_fix = len(code)
    code.extend(bytes(4))
    code.extend(bytes.fromhex('41 8b 94 80'))       # EDX=targets[EAX]
    table_fix = len(code)
    code.extend(bytes(4))
    code.extend(bytes.fromhex('4c 01 c2 ff e2'))    # RDX+=base; JMP RDX
    label('flight')
    ret(300)
    label('ball')
    ret(240)
    label('retry')
    code.extend(bytes.fromhex('8b 11 83 fa 08'))   # EDX=store->mode; CMP mode,8
    branch('0f 84', 'default')                    # reject self retry
    code.extend(bytes.fromhex('83 c2 fb 83 fa 03'))
    branch('0f 86', 'lookup')                     # JBE lookup
    label('default')
    ret(270)

    for offset, target in branches:
        struct.pack_into('<i', code, offset, labels[target] - offset - 4)
    map_at = OFFSET + len(code)
    table_at = (map_at + len(MAP) + 3) & -4
    struct.pack_into('<i', code, base_fix, BASE - ENTRY - base_fix - 4)
    struct.pack_into('<i', code, map_fix, map_at)
    struct.pack_into('<i', code, table_fix, table_at)
    payload = code + MAP + bytes(table_at - map_at - len(MAP))
    payload += b''.join(struct.pack('<I', OFFSET + labels[n])
                        for n in ('flight', 'ball', 'retry', 'default'))
    # SysV -> MSABI tail bridge, used only for optional native verification.
    bridge_at = OFFSET + len(payload)
    payload += bytes.fromhex('48 89 f9 89 f2 e9')
    payload += struct.pack('<i', OFFSET - bridge_at - 10)
    size = OFFSET + len(payload)
    ident = b'\x7fELF\x02\x01\x01' + bytes(9)
    hdr = struct.pack('<16sHHIQQQIHHHHHH', ident, 2, 62, 1, ENTRY, 64, 0, 0, 64, 56, 1, 0, 0, 0)
    phdr = struct.pack('<IIQQQQQQ', 1, 5, 0, BASE, BASE, size, size, 0x1000)
    return (hdr + phdr).ljust(OFFSET, b'\0') + payload, len(code), bridge_at


def expected(mode, stored):
    if mode == 8:
        mode = stored
    return 300 if mode == 5 else 240 if mode == 7 else 270


def native_check(image, bridge_at):
    if platform.machine() not in ('x86_64', 'AMD64') or platform.system() != 'Linux':
        raise SystemExit('--native-check requires x86-64 Linux')
    with mmap.mmap(-1, len(image), prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC) as mem:
        mem.write(image)
        anchor = ctypes.c_char.from_buffer(mem)
        fn = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.c_uint)(
            ctypes.addressof(anchor) + bridge_at)
        count = 0
        values = list(range(0, 16)) + [0xffffffff]
        for mode in values:
            for stored in values:
                cell = ctypes.c_uint(stored)
                got = fn(ctypes.byref(cell), mode)
                assert got == expected(mode, stored), (mode, stored, got)
                count += 1
        del fn, anchor
    print(f'Native fixture matches the reference for {count} input pairs.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--kuna')
    ap.add_argument('--sleighpath')
    ap.add_argument('--output', type=Path, default=Path('output'))
    ap.add_argument('--build-only', action='store_true')
    ap.add_argument('--native-check', action='store_true')
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    image, size, bridge_at = build()
    binary = args.output / 'compact-switch.elf'
    declarations = args.output / 'compact-switch.kuna'
    binary.write_bytes(image)
    declarations.write_text(
        'typedef struct ModeStore { unsigned int mode; };\n'
        f'function {ENTRY:#x}-{ENTRY + size:#x}=compact_dispatch\n'
        'prototype compact_dispatch int MSABI compact_dispatch(struct ModeStore *store, unsigned int mode)\n')
    print(f'Fixture: {len(image)} bytes, {size} instruction bytes, map [0,3,1,2].')
    print('mode=7: index=2, map[2]=1, target[1] returns240 (not270).')
    if args.native_check:
        native_check(image, bridge_at)
    if args.build_only:
        return
    if not args.kuna:
        ap.error('--kuna is required unless --build-only is given')
    print(subprocess.check_output([args.kuna, '--version'], text=True).strip())
    command = [args.kuna, 'decompile-all', str(binary), '--addr', hex(ENTRY),
               '--mode', 'reliable', '--assert-strict', '--json', '--assert', '@' + str(declarations)]
    if args.sleighpath:
        command += ['--sleighpath', args.sleighpath]
    result = subprocess.run(command, capture_output=True, text=True, timeout=120)
    (args.output / 'output.json').write_text(result.stdout)
    (args.output / 'stderr.txt').write_text(result.stderr)
    if result.returncode:
        raise SystemExit(result.stderr)
    data = json.loads(result.stdout)
    rejected = [a for a in data.get('assertions', []) if a['status'] != 'applied']
    print(f'Rejected assertions: {len(rejected)}')
    code = '\n\n'.join(f.get('code', '') for f in data.get('functions', []))
    (args.output / 'code.c').write_text(code + '\n')
    print(code)
    if rejected:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
