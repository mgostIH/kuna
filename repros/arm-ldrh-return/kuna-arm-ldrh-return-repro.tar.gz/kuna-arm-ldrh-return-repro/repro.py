#!/usr/bin/env python3
"""ROM-free ARM LDRH signed-return reduction; Python-only ELF builder/runner."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess

TEXT = 0x10000
STATE = 0x11000
SCALE = 0x1001C
# Independently authored ARMv5TE words, documented in fixture.s.
WORDS = [0xE59F1010, 0xE1D100B0, 0xE2800001, 0xE1C100B0,
         0xE1D100B0, 0xE12FFF1E, STATE,
         0xE92D4010, 0xE1A04000, 0xEBFFFFF5, 0xE0000094,
         0xE1A00840, 0xE8BD8010]
BASE_ASSERTIONS = [
    'function 0x10000-0x10018=Next',
    'function 0x1001c-0x10034=Scale',
    'readonly 0x10018+4',
    'prototype Scale int Scale(int bound)',
]
CONTROL = 'prototype Next unsigned short Next(void)'


def build_elf():
    """ELF32 little-endian ARM, two PT_LOAD segments, three ordinary symbols."""
    text = struct.pack('<13I', *WORDS)
    data = struct.pack('<H', 0x7FFF)
    strings = b'\0Next\0Scale\0state16\0'
    names = b'\0.text\0.data\0.symtab\0.strtab\0.shstrtab\0'
    image = bytearray(0x100)
    text_offset = len(image)
    image.extend(text)
    data_offset = len(image)
    image.extend(data)
    string_offset = len(image)
    image.extend(strings)
    name_offset = len(image)
    image.extend(names)
    image.extend(bytes((-len(image)) % 4))
    symbol_offset = len(image)
    image.extend(bytes(16))
    for name, address, size, kind, section in [(1, TEXT, 24, 0x12, 1),
                                              (6, SCALE, 24, 0x12, 1),
                                              (12, STATE, 2, 0x11, 2)]:
        image.extend(struct.pack('<IIIBBH', name, address, size, kind, 0, section))
    section_offset = len(image)
    headers = [bytes(40),
               struct.pack('<10I', 1, 1, 6, TEXT, text_offset, len(text), 0, 0, 4, 0),
               struct.pack('<10I', 7, 1, 3, STATE, data_offset, len(data), 0, 0, 2, 0),
               struct.pack('<10I', 13, 2, 0, 0, symbol_offset, 64, 4, 1, 4, 16),
               struct.pack('<10I', 21, 3, 0, 0, string_offset, len(strings), 0, 0, 1, 0),
               struct.pack('<10I', 29, 3, 0, 0, name_offset, len(names), 0, 0, 1, 0)]
    image.extend(b''.join(headers))
    image[:52] = struct.pack('<16sHHIIIIIHHHHHH', b'\x7fELF\x01\x01\x01' + bytes(9),
                             2, 40, 1, SCALE, 52, section_offset, 0x05000000,
                             52, 32, 2, 40, 6, 5)
    image[52:116] = b''.join([
        struct.pack('<8I', 1, text_offset, TEXT, TEXT, len(text), len(text), 5, 4),
        struct.pack('<8I', 1, data_offset, STATE, STATE, len(data), len(data), 6, 4)])
    return bytes(image)


def priority_command():
    if not shutil.which('nice'):
        raise RuntimeError('Linux nice is required for low-priority Kuna execution')
    prefix = ['nice', '-n', '15']
    if shutil.which('ionice'):
        prefix = ['ionice', '-c', '3'] + prefix
    return prefix


def execute(kuna, specs, out, name, assertions):
    path = out / (name + '.kuna')
    path.write_text('\n'.join(assertions) + '\n')
    env = {**os.environ, 'KUNA_SPECS': str(specs), 'KUNA_DECODE_JOBS': '1'}
    command = priority_command() + [str(kuna), 'decompile-all', str(out / 'fixture.elf'),
              '--mode', 'reliable', '--language', 'c', '--jobs', '1', '--json',
              '--target', 'ARM:LE:32:v5t:default', '--isa', 'arm',
              '--assert', '@' + str(path), '--assert-strict',
              '--addr', hex(TEXT), '--addr', hex(SCALE)]
    with (out / (name + '.json')).open('w') as stdout, (out / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(command, env=env, stdout=stdout, stderr=stderr, timeout=30)
    payload = json.loads((out / (name + '.json')).read_text())
    if result.returncode or payload['error'] or len(payload['functions']) != 2:
        raise RuntimeError(f'{name}: operational failure; inspect JSON/stderr')
    if any(f['error'] for f in payload['functions']):
        raise RuntimeError(f'{name}: function error')
    statuses = payload.get('assertions', [])
    if len(statuses) != len(assertions) or any(row['status'] != 'applied' for row in statuses):
        raise RuntimeError(f'{name}: assertions not all applied')
    functions = {f['name']: f['code'] for f in payload['functions']}
    if set(functions) != {'Next', 'Scale'}:
        raise RuntimeError(f'{name}: unexpected function names {list(functions)}')
    (out / (name + '.c')).write_text('\n\n'.join(functions.values()) + '\n')
    print(f'{name}: {len(assertions)}/{len(assertions)} assertions applied')
    print('\n\n'.join(functions.values()))
    return functions


def verify_execution(out, variants):
    """Optional real ARM execution and compiled emission, outside the core runner."""
    import ctypes
    from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM
    from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_LR, UC_ARM_REG_SP, UC_ARM_REG_PC

    machine = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    machine.mem_map(TEXT, 0x2000)
    machine.mem_map(0x200000, 0x1000)
    machine.mem_map(0x300000, 0x1000)
    machine.mem_write(TEXT, struct.pack('<13I', *WORDS))
    machine.mem_write(STATE, struct.pack('<H', 0x7FFF))
    machine.reg_write(UC_ARM_REG_R0, 100)
    machine.reg_write(UC_ARM_REG_SP, 0x200FF0)
    machine.reg_write(UC_ARM_REG_LR, 0x300000)
    machine.emu_start(SCALE, 0x300000, count=64)
    arm_result = machine.reg_read(UC_ARM_REG_R0)
    arm_state = int.from_bytes(machine.mem_read(STATE, 2), 'little')
    if machine.reg_read(UC_ARM_REG_PC) != 0x300000 or (arm_result, arm_state) != (50, 0x8000):
        raise AssertionError('Synthetic ARM did not finish with expected result/state')
    print(f'Actual ARM: result={arm_result}, state={arm_state:#06x}')
    results = {'arm': {'result': arm_result, 'state': arm_state}}
    prelude = ('typedef short int2; typedef int int4; typedef unsigned short uint2; '
               'typedef unsigned int uint4; unsigned short state16;\n'
               '_Static_assert(sizeof(short)==2 && sizeof(int)==4, "required widths");\n')
    for name, functions in variants.items():
        source, library = out / (name + '-check.c'), out / (name + '-check.so')
        source.write_text(prelude + '\n\n'.join(functions.values()) + '\n')
        subprocess.run(['gcc', '-shared', '-fPIC', '-O0', '-o', str(library), str(source)], check=True)
        module = ctypes.CDLL(str(library.resolve()))
        state = ctypes.c_ushort.in_dll(module, 'state16')
        state.value = 0x7FFF
        module.Scale.argtypes = [ctypes.c_int]
        module.Scale.restype = ctypes.c_int
        result = module.Scale(100)
        expected = -50 if name == 'baseline' else 50
        if (result, state.value) != (expected, 0x8000):
            raise AssertionError(f'{name}: result/state differed from expected')
        results[name] = {'result': result, 'state': state.value}
        print(f'{name} compiled C: result={result}, state={state.value:#06x}')
    (out / 'execution.json').write_text(json.dumps(results, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kuna', type=Path, help='Kuna executable (external prerequisite)')
    parser.add_argument('--sleighpath', type=Path, help='specs root containing built ARM5t_le.sla')
    parser.add_argument('--output', type=Path, default=Path('output'))
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--verify', action='store_true', help='Optional Unicorn + GCC execution checks')
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    fixture = build_elf()
    (out / 'fixture.elf').write_bytes(fixture)
    print(f'Fixture: {len(fixture)} bytes, SHA-256 {hashlib.sha256(fixture).hexdigest()}')
    if args.build_only:
        return
    if args.kuna is None or args.sleighpath is None:
        parser.error('--kuna and --sleighpath are required unless --build-only')
    kuna, specs = args.kuna.resolve(), args.sleighpath.resolve()
    env = {**os.environ, 'KUNA_SPECS': str(specs), 'KUNA_DECODE_JOBS': '1'}
    version = subprocess.check_output(priority_command() + [str(kuna), '--version'], env=env, text=True).strip()
    print(version)
    (out / 'identity.json').write_text(json.dumps({'version': version,
        'invoked_executable_sha256': hashlib.sha256(kuna.read_bytes()).hexdigest(),
        'fixture_sha256': hashlib.sha256(fixture).hexdigest(),
        'target': 'ARM:LE:32:v5t:default', 'mode': 'reliable'}, indent=2) + '\n')
    variants = {'baseline': execute(kuna, specs, out, 'baseline', BASE_ASSERTIONS),
                'unsigned': execute(kuna, specs, out, 'unsigned', BASE_ASSERTIONS + [CONTROL])}
    signed = bool(re.match(r'(?:int2|short|signed short)\s+Next\(', variants['baseline']['Next']))
    unsigned = bool(re.match(r'(?:uint2|unsigned short)\s+Next\(', variants['unsigned']['Next']))
    if not signed or not unsigned or 'Next()' not in variants['baseline']['Scale']:
        raise RuntimeError('Reported signed-return defect/control no longer match; inspect outputs')
    if args.verify:
        verify_execution(out, variants)
    print('Reported signed-halfword defect and unsigned control reproduced.')


if __name__ == '__main__':
    main()
