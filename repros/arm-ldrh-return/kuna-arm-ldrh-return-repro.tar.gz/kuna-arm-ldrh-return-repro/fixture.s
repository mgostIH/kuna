/* Independently authored; repro.py emits these 52 text bytes without an assembler.
 * Next increments a writable halfword then returns a zero-extending reload.
 * The literal pointer is data outside Next's asserted executable bounds. */
.syntax unified
.arch armv5te
.arm
.text
Next:                         /* 0x10000 */
    ldr r1, state_pointer
    ldrh r0, [r1]
    add r0, r0, #1
    strh r0, [r1]
    ldrh r0, [r1]
    bx lr
state_pointer: .word 0x11000   /* 0x10018 */
Scale:                        /* 0x1001c */
    push {r4, lr}
    mov r4, r0
    bl Next
    mul r0, r4, r0
    asr r0, r0, #16
    pop {r4, pc}
/* Writable halfword state16 at 0x11000 starts at 0x7fff. */
