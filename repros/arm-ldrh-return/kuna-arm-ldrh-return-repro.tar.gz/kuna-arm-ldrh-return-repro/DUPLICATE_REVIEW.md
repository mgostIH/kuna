Reviewed 2026-10-02. Official main resolved to 5dd534d8df3f26c9e2c972f12610cbc7773d1d44.

Issue-only searches for LDRH and halfword: no matches. Issue/PR LDRH search: only unrelated PR431 (literal-pool/string ownership). Broader unsigned-return results screened; issue769 (64-bit zero-extended return narrowed to signed32) and issue816 (declared narrow MIPS/RISC-V returns) read directly. No exact duplicate found; inference is related to769. Search terminology can miss a duplicate.

https://github.com/Noelo-Lab/kuna/issues/769
https://github.com/Noelo-Lab/kuna/issues/816
https://github.com/Noelo-Lab/kuna/pull/431
