int2 Next(void)
{
  state16 += 1;
  return state16;
}

int4 Scale(int4 bound)
{
  return bound * Next() >> 0x10;
}
