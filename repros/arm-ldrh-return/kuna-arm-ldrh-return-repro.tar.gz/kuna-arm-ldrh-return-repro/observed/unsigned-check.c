typedef short int2; typedef int int4; typedef unsigned short uint2; typedef unsigned int uint4; unsigned short state16;
_Static_assert(sizeof(short)==2 && sizeof(int)==4, "required widths");
uint2 Next(void)
{
  state16 += 1;
  return state16;
}

int4 Scale(int4 bound)
{
  return (int4)(bound * (uint4)Next()) >> 0x10;
}
