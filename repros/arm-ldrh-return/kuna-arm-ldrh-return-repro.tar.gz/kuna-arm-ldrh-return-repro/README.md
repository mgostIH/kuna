# ARM LDRH signed-return reduction

Python 3.9+, Linux `nice`, an external Kuna binary and built ARM SLEIGH specs
are the core prerequisites. No compiler, assembler, game files or third-party
Python packages are needed to generate the ELF and reproduce the emission.

```sh
python3 repro.py --kuna /absolute/path/to/kuna --sleighpath /absolute/path/to/specs
```

The runner builds a tiny ELF, runs two serial reliable/strict cases at nice +15
and idle I/O priority, checks error fields and all 4/5 assertion statuses, and
saves fresh JSON, C, stderr and identity metadata under `output/`. Exit 0 means
the reported signed-halfword defect and unsigned control reproduced. A fixed
Kuna will fail that expected-defect check; inspect its new output.

To regenerate only the synthetic ELF:

```sh
python3 repro.py --build-only
```

Optional instruction execution and compiled-C comparison require Unicorn
2.1.4 and GCC on a host with 16-bit short and 32-bit int:

```sh
uv run --with unicorn==2.1.4 python repro.py \
  --kuna /absolute/path/to/kuna --sleighpath /absolute/path/to/specs --verify
```

With state `0x7fff` and bound 100, actual ARM returns 50 with state `0x8000`.
Baseline C returns -50 with the same state. Adding only an unsigned-short
prototype for Next makes compiled C return 50. There is no signed overflow
in this counterexample; negative signed shift behavior is checked on GCC/Linux.

`fixture.s` documents the authored instructions. `repro.py` uses Python's
standard library to construct the ELF and is the executable source of the
fixture. `observed/` contains the tested ELF, directives, emission and execution
record. Kuna/spec binaries and host shared libraries are deliberately omitted.
`SHA256SUMS` fingerprints the shipped files. Everything in the observed results
can be recreated; no ROM bytes, assets or game declarations are included.
