from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
subprocess.run(["clang", "-nostdlib", "-no-pie", "-Wl,-Ttext=0x401000", "-Wl,-e,_check_start", "-o", str(root / "repro.elf"), str(root / "repro.S")], check=True)
subprocess.run([str(root / "repro.elf")], check=True)
print("Native fixture passed: stack=67, register=81, escaped alias=7, observations=162")
