import argparse, json, os, subprocess
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--kuna',required=True)
parser.add_argument('--sleighpath')
args=parser.parse_args()
root=Path(__file__).resolve().parent
kuna=Path(args.kuna).resolve()
env=os.environ.copy()
env['KUNA_DECOMP_DBG']=str(kuna.parent/'decomp_dbg')
env['SLEIGHHOME']=args.sleighpath or str(kuna.parent/'specs')
for case,function,extra in [('register-baseline','0x401120',[]),('register-names','0x401120',['register-names.kuna']),('stack-typed','0x401040',['typed.kuna']),('escaped-alias','0x4010b0',[])]:
 command=[str(kuna),'decompile',str(root/'repro.elf'),function,'--mode','reliable','--json','--assert-strict','--assert','@'+str(root/'baseline.kuna')]
 for name in extra:command+=['--assert','@'+str(root/name)]
 result=subprocess.run(command,env=env,capture_output=True,text=True)
 out=root/'results'/case;out.mkdir(parents=True,exist_ok=True)
 (out/'output.json').write_text(result.stdout);(out/'stderr.txt').write_text(result.stderr)
 print('\n'+case,'exit',result.returncode)
 print(result.stderr)
 doc=json.loads(result.stdout)
 for f in doc.get('functions',[]):print(f.get('code',''))
 for a in doc.get('assertions',[]):
  if a.get('status')!='applied':print(a)
