typedef int int4;
typedef unsigned long long uint8;
static unsigned long long total;
unsigned long long consume_number(unsigned long long n) { return n * 2; }
const int *identity_pointer(const int *p) { return p; }
void observe_number(unsigned long long n) { total += n; }
void observe_pointer(const int *p) { total += *p; }
void register_names(unsigned long long a0, int *a1)
{
    unsigned long long recovered_number;  // rbx
    int *recovered_pointer;  // rbx

    recovered_number = consume_number(a0);
    observe_number(recovered_number);
    observe_number(recovered_number);
    recovered_pointer = identity_pointer(a1);
    observe_pointer(recovered_pointer);
    observe_pointer(recovered_pointer);
    return;
}

int main(void) { int datum=55; register_names(13, &datum); return total != 162; }
