void register_names(unsigned long long a0, int *a1)
{
    unsigned long long recovered_number;  // rbx
    int *recovered_pointer;  // rbx

    recovered_number = consume_number(a0);
    observe_number(recovered_number);
    observe_number(recovered_number);
    recovered_pointer = identity_pointer(a1);
    observe_pointer(recovered_pointer);
    observe_pointer(recovered_pointer);
    return;
}
