#include <stdint.h>
typedef int int4; typedef unsigned long long uint8;
typedef struct LifetimePair {int x,y;} LifetimePair;
typedef struct LifetimeHandle {const int *value;} LifetimeHandle;
int datum=55;
int read_pair(const LifetimePair *p){return p->x+p->y;}
int read_handle(const LifetimeHandle *p){return *p->value;}
uint8 consume_number(uint8 n){return n*2;}
uint8 read_value(const int *p){return (unsigned int)*p;}
int *escaped_pointer;
int4 stack_reuse(void)
{
  int4 v1; // eax
  LifetimePair v2 [2]; // stack - 0x18
  
  v2[0].x = 5;
  v2[0].y = 7;
  v1 = read_pair(v2);
  v2[0] = &datum;
  return read_handle((LifetimeHandle *)v2) + v1;
}

uint8 register_reuse(uint8 input,int4 *pointer)
{
  uint8 v1; // rax
  
  v1 = consume_number(input + 3);
  return read_value(pointer) + v1;
}

int4 escaped_alias(void)
{
  int4 v1 [4];
  
  escaped_pointer = v1;
  return 7;
}
