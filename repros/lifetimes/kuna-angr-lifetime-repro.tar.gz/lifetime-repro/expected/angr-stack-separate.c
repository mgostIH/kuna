
int stack_reuse(void)
{
    unsigned int v4;  // eax
    int v0[2];  // [bp-0x18]
    unsigned long v1;  // [bp-0x18]
    unsigned int v2;  // [bp-0x14]

    v0 = 5;
    v2 = 7;
    v4 = read_pair(v0);
    v1 = "7";
    return (read_handle(&v1) & 0xffffffff) + v4;
}
