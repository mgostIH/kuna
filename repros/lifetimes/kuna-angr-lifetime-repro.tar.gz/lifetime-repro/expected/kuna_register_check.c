typedef int int4;
typedef unsigned long long uint8;
static unsigned long long total;
unsigned long long consume_number(unsigned long long n) { return n * 2; }
const int *identity_pointer(const int *p) { return p; }
void observe_number(unsigned long long n) { total += n; }
void observe_pointer(const int *p) { total += *p; }
void register_names(uint8 input,int4 *pointer)
{
  uint8 number; // rax
  int4 *pointer_00; // rax
  
  number = consume_number(input);
  observe_number(number);
  observe_number(number);
  pointer_00 = identity_pointer(pointer);
  observe_pointer(pointer_00);
  observe_pointer(pointer_00);
  return;
}

int main(void) { int datum=55; register_names(13, &datum); return total != 162; }
