
int stack_reuse(void)
{
    unsigned int v3;  // eax
    int v0[2];  // [bp-0x18], Other Possible Types: unsigned long
    unsigned int v1;  // [bp-0x14]

    v0 = 5;
    v1 = 7;
    v3 = read_pair(v0);
    v0 = "7";
    return (read_handle(&v0) & 0xffffffff) + v3;
}
