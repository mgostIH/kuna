from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
for engine in ("kuna", "angr"):
    bad = root / "expected" / (engine + "_compile.c")
    result = subprocess.run(["clang", "-fsyntax-only", str(bad)], capture_output=True, text=True)
    print(engine, "stack snapshot syntax exit:", result.returncode)
    print(result.stderr)
    if not result.returncode:
        raise SystemExit("Expected the recorded invalid stack snapshot to fail")
    good = root / "expected" / (engine + "_register_check.c")
    binary = root / (engine + "-register-check")
    subprocess.run(["clang", "-O0", "-o", str(binary), str(good)], check=True)
    subprocess.run([str(binary)], check=True)
    print(engine, "register snapshot observations=162: passed")
