# Minimal lifetime comparison (asset-free)

Four authored x86-64 SysV functions; no game bytes or external binary dependencies.
The ELF starts at preferred base 0x400000. stack_reuse is RVA1040/VA401040,
register_reuse RVA1080/VA401080, escaped_alias RVA10b0/VA4010b0,
register_names RVA1120/VA401120. Stack slots are described relative to entry RSP.
The supplied ELF SHA256 is 30d786f5445462fd300c5f7b3d1b1d8f415dc097d2ca5f00082ae1b9e4f33ae4.

stack_reuse uses the same 8 bytes first as {5,7}, then as a pointer to55.
Both helpers' exact definitions are supplied and do not retain the incoming address.
register_names keeps a number and later a pointer in the same physical registers,
with two observable uses per value and no live overlap. escaped_alias requires
an earlier saved pointer to see a later write through the original stack address;
it is a safety control, not an example safe to split into independent objects.

Versions tested:
- Kuna local source 7711215214a3e8b4d24d74bb704d44d451e441b9.
- angr 10.0.2.dev0, source 332904765e65353e0164574d298300ca2b8e89eb.
- Ubuntu clang18.1.3, Linuxx86-64.

Rebuilding may change non-executable temporary assembler filename metadata and
thus the ELF hash; the supplied executable is the exact tested binary.

Build/run native reference (clang and system linker required):

```sh
python3 build.py
python3 check_emission.py
```

check_emission verifies the saved snapshots, not freshly emitted output. Both
stack snapshots must fail C syntax checking. Both register snapshots compile and
produce162 (const qualifier warnings remain). Native reference additionally
checks stack67, arithmetic register81 and escaped alias7. Not exhaustive behavior.

Standalone Kuna reproduction (Python standard library; supplied ELF needs no compiler):

```sh
python3 reproduce_kuna.py --kuna /absolute/path/to/kuna --sleighpath /absolute/path/to/specs
```

It prints the four selected cases and saves results beside the script. The naming
case intentionally fails; inspect changed emission when testing a candidate fix.
Both failures were additionally confirmed on the official Kuna v1.624 release.

Extract this archive into ignored generated/ in the GD project. Use the project
runner and its shared analysis lock. Let REPRO be the extraction directory:

```sh
uv run tools/project.py decompile 0x401040 0x401080 0x4010b0 --scratch --module "$REPRO/repro.elf" --assert "$REPRO/baseline.kuna" --assert "$REPRO/typed.kuna" --output "$REPRO/kuna-typed"
uv run tools/project.py decompile 0x401120 --scratch --module "$REPRO/repro.elf" --assert "$REPRO/baseline.kuna" --output "$REPRO/kuna-register"
uv run tools/project.py decompile 0x401120 --scratch --module "$REPRO/repro.elf" --assert "$REPRO/baseline.kuna" --assert "$REPRO/register-names.kuna" --output "$REPRO/kuna-register-named"
```

The last command intentionally exits1 with two shared-storage rejections.
Others pass strict assertions despite the invalid typed stack body.

angr requires a build of the pinned checkout and its dependencies (uv, Rust).
The existing project environment is toolchain/angr-env. To recreate it, with one
build job and the shared lock held:

```sh
UV_PROJECT_ENVIRONMENT="$PWD/toolchain/angr-env" CARGO_TARGET_DIR="$PWD/toolchain/angr-target" CARGO_BUILD_JOBS=1 CARGO_PROFILE_RELEASE_DEBUG=0 uv sync --project /path/to/angr --no-default-groups
flock generated/.kuna-analysis.lock nice -n 15 ionice -c 3 toolchain/angr-env/bin/python "$REPRO/run_angr.py" --typed
flock generated/.kuna-analysis.lock nice -n 15 ionice -c 3 toolchain/angr-env/bin/python "$REPRO/run_angr.py" --typed --keep-stack-identities
flock generated/.kuna-analysis.lock nice -n 15 ionice -c 3 toolchain/angr-env/bin/python "$REPRO/run_angr.py" --typed --rename-registers
```

The diagnostic --keep-stack-identities overrides only the interference predicate
consulted for extra same-offset stack coalescing. It is not an angr fix: the
aggregate remains invalid and phi unification is unchanged. Source files are not
patched. --rename-registers renames the two unified register variables and asks
codegen to regenerate; both names persist. Each run writes C and variables.json
beside this script. The default preset and auto_load_libs=False are used.

Inspect variables.json: default is_1 (offset-24,size4) and is_3(offset-24,size8)
share unified_ident is_1. Diagnostic separation gives is_3 its own identity.
The optional Unicorn library failed to load in our environment; all static runs
and both focused upstream SSA tests still completed successfully.

These are focused examples, not a benchmark or a proof of general alias recovery.
