from pathlib import Path
import argparse, json, logging, time
import angr
from angr.sim_type import parse_defns
from angr.calling_conventions import SimCCSystemVAMD64
logging.getLogger('angr').setLevel(logging.WARNING)
p=argparse.ArgumentParser();p.add_argument('--typed',action='store_true');p.add_argument('--keep-stack-identities',action='store_true');p.add_argument('--rename-registers',action='store_true');a=p.parse_args()
if a.keep_stack_identities:
 from angr.knowledge_plugins.variables.variable_manager import VariableManagerInternal
 def never_coalesce_stack(self, interference, left, right):
  return True
 VariableManagerInternal._variables_interfere=never_coalesce_stack
root=Path(__file__).resolve().parent
proj=angr.Project(str(root/'repro.elf'),auto_load_libs=False)
started=time.monotonic()
cfg=proj.analyses.CFGFast(normalize=True)
defns='''
struct LifetimePair { int x; int y; };
struct LifetimeHandle { const int *value; };
int stack_reuse(void);
unsigned long long register_reuse(unsigned long long input, const int *pointer);
int escaped_alias(void);
void register_names(unsigned long long input, const int *pointer);
const int *identity_pointer(const int *pointer);
void observe_number(unsigned long long number);
void observe_pointer(const int *pointer);
unsigned long long consume_number(unsigned long long number);
unsigned long long read_value(const int *pointer);
'''+('''int read_pair(const struct LifetimePair *pair);
int read_handle(const struct LifetimeHandle *handle);''' if a.typed else '''int read_pair(const int *pair);
int read_handle(const int **handle);''')
for name,proto in parse_defns(defns).items():
 f=proj.kb.functions.function(name=name)
 if f is None:raise RuntimeError(name)
 f.prototype=proto.with_arch(proj.arch);f.calling_convention=SimCCSystemVAMD64(proj.arch)
folder=root/(('angr-typed' if a.typed else 'angr-baseline')+('-separate' if a.keep_stack_identities else '')+('-named' if a.rename_registers else ''));folder.mkdir(exist_ok=True)
results=[]
for name in ['stack_reuse','register_reuse','escaped_alias','register_names']:
 f=proj.kb.functions.function(name=name)
 dec=proj.analyses.Decompiler(f,cfg=cfg.model)
 if dec.codegen is None:raise RuntimeError((name,dec.errors))
 if a.rename_registers and name == 'register_names':
  vm=proj.kb.dec_variables[f.addr]
  chosen={}
  for v in vm.get_variables():
   u=vm.unified_variable(v)
   if u is not None and u.name in ('v1','v2'):
    chosen[u.name]=u
  if set(chosen) != {'v1','v2'}:raise RuntimeError(('rename targets',chosen))
  chosen['v1'].name='recovered_number';chosen['v1'].renamed=True
  chosen['v2'].name='recovered_pointer';chosen['v2'].renamed=True
  dec.codegen.regenerate_text()
 code=dec.codegen.text
 (folder/f'{name}.c').write_text(code)
 print(code,flush=True)
 vm=proj.kb.dec_variables[f.addr]
 variables=[]
 for v in vm.get_variables():
  u=vm.unified_variable(v)
  variables.append(dict(ident=v.ident,name=v.name,kind=type(v).__name__,offset=getattr(v,'offset',None),reg=getattr(v,'reg',None),size=v.size,unified_ident=getattr(u,'ident',None),unified_name=getattr(u,'name',None),type=str(vm.get_variable_type(v))))
 results.append(dict(function=name,address=hex(f.addr),variables=variables))
(folder/'variables.json').write_text(json.dumps(results,indent=2)+'\n')
print('angr',angr.__version__,'module',angr.__file__,'elapsed',round(time.monotonic()-started,2),flush=True)
